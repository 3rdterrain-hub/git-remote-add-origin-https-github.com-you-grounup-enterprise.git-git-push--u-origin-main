# Reports

| report_id | name | purpose | formats |
|---|---|---|---|
| GES-P05-RPT-001 | Estimate Summary | Scope, direct cost, sell, margin and alternates. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-002 | Detailed Cost Build-Up | Resource-level cost and markup detail. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-003 | Estimate Review Book | Assumptions, exclusions, risks, overrides and approvals. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-004 | Calculation Trace Report | Every amount with source and formula lineage. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-005 | Production & Duration Report | Crews, equipment, outputs, hours and schedule assumptions. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-006 | Haul Analysis | Cycle time, truck count, payload, queues and cost. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-007 | Risk & Confidence Report | Uncertainty, sensitivity and confidence drivers. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-008 | Scenario Comparison | Baseline versus alternatives. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-009 | Vendor Quote Comparison | Normalized quote comparison and exceptions. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-010 | Historical Estimate vs Actual | Cost, quantity, hours and production variance. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-011 | Calibration Proposal Report | Suggested rate updates with evidence. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-012 | Regional Price Variance | Local versus baseline prices and factors. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-013 | Bid Margin Waterfall | Direct cost through final sell price. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-014 | White-Label Configuration Audit | Inherited and overridden branding/configuration. | Web, PDF, XLSX, CSV, JSON |
| GES-P05-RPT-015 | Executive Estimating KPI | Pipeline, win rate, cycle time, margin and accuracy. | Web, PDF, XLSX, CSV, JSON |