# Phase 10 UI/UX Specification

The user experience uses GrounUp black, white, and construction yellow branding; supports tenant white-label configuration; and exposes only authorized financial data.

| ID | Surface | Channel | Core Experience | Standards |
|---|---|---|---|---|
| UI-P10-01 | CFO Command Center | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-02 | Controller Close Workspace | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-03 | General Ledger Workbench | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-04 | Accounts Payable Workspace | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-05 | Payment Approval Center | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-06 | Accounts Receivable & Collections | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-07 | Construction Billing Workspace | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-08 | Project Financial Control Center | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-09 | WIP & Revenue Recognition Center | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-10 | Cash & Treasury Dashboard | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-11 | Fixed Assets Workspace | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-12 | Tax & Compliance Workspace | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-13 | Financial Reporting Studio | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-14 | AI Financial Intelligence Center | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-15 | Financial Administration & Configuration | Responsive web | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-16 | Mobile Finance Approvals | Mobile/Portal | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-17 | Vendor Financial Portal | Mobile/Portal | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |
| UI-P10-18 | Customer Billing Portal | Mobile/Portal | Role-based cards, work queues, filters, drill-down, evidence, approvals | Accessible, configurable, white-label capable |