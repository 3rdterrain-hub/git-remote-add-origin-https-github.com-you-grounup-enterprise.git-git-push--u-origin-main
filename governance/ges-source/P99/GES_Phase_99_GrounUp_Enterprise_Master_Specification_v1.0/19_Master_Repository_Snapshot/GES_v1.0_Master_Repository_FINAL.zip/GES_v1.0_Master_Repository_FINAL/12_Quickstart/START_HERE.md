# START HERE
1. Read `00_Master_Control/README.md`.
2. Read `08_QA_Validation/GES_Master_Preflight_Report.md`.
3. Review `04_Build_Sequence/GES_Implementation_Waves.csv`.
4. Review `05_Dependency_Map/GES_Master_Dependency_Map.mmd`.
5. Read `06_AI_Developer_Implementation/GES_MASTER_AI_DEVELOPER_INSTRUCTIONS.md`.
6. Select a requirement slice from the governing phase and implement through its tests/gates.
7. Follow `07_Deployment_Roadmap/GES_v1.0_Deployment_Roadmap.md`.
8. Never mark production certified until real Phase 32 evidence exists.
